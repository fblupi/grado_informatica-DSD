# Práctica 2 #

## Implementar chat público y privado con RMI ##

### Instrucciones ###

#### Windows

* Para compilar, abrir los proyectos con NetBeans y hacer "build".
* Para ejecutar, moverse al directorio build/classes del chat que se quiera utilizar y ejecutar el archivo lanzaRMI.bat seguido de lanzaServidor.bat y tantos lanzaCliente.bat como clientes se quieran utilizar.

#### Linux

* Para compilar, abrir los proyectos con NetBeans y hacer "build".
* Para ejecutar, moverse al directorio build/classes del chat que se quiera utilizar y cambiar los archivos .bat por .sh con las resepctivas modificaciones en el interior para su correcto funcionamiento en linux. 
* Ejecutar el archivo lanzaRMI.sh seguido de lanzaServidor.sh y tantos lanzaCliente.sh como clientes se quieran utilizar.

### Autor ###

* Francisco Javier Bolívar Lupiáñez